# -*- coding: utf-8 -*-

# Este módulo proporciona generadores para los grafos (no
# dirigidos) y para los grafos dirigidos en n vértices no
# etiquetados.
#
# Estos generadores almacenan en memoria los grafos ya
# calculados y, basándose en los generadores etiquetados
# correspondientes, comprueban para cada nuevo elemento si
# ya se ha generado un grafo isomorfo, descartándolo en ese
# caso.

import importlib

import networkx as nx

m1 = importlib.import_module("00_sol_01")
m2 = importlib.import_module("00_sol_02")


def ya_esta(g, lista):
    """Decide si en lista ya hay un grafo isomorfo a g."""

    for h in lista:
        if nx.is_isomorphic(g, h):
            return True
    return False


def no_etiq(generador):
    lista = list()
    for g in generador:
        if not ya_esta(g, lista):
            yield g
            lista.append(g)


no_d_no_etiq = lambda n: no_etiq(m1.no_d_etiq(n))
d_no_etiq = lambda n: no_etiq(m2.d_etiq(n))


def no_d_no_etiq(n):
    lista = list()
    # TODO: retornar todos los grafos etiquetados


def d_no_etiq(n):
    lista = list()
    # TODO: retornar todos los grafos no etiquetados
